﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using System.Text.RegularExpressions;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class ResultSuggest : MonoBehaviour
{
    private List<string> id = new List<string>();
    private List<string> titleLs = new List<string>();
    private static List<string> suggstLst = new List<string>();
    private static string rcpClick;
    private static string thisScene = "SuggstLstSc";
    public GameObject rcpItem;
    GameObject newObj;
    
    
    // Start is called before the first frame update
    void Start()
    {
        readRecipe();
        int crt = id.Count;
        for(int x=0; x< crt; x++)
        {
            if(suggstLst.Contains(id[x]))
                RecipeInstantiate(titleLs[x], id[x]);
        }
        GameObject.Find("Scroll").GetComponent<ScrollRect>().verticalNormalizedPosition = 1;
        GameObject.Find("BtnBack").GetComponent<Button>().onClick.AddListener(()=>{btnBack();});
    }
    void Update()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                btnBack();
                return;
            }
        }
    }

    public static void setsuggstLst(List<string> myList)
    {
        suggstLst = myList;
    }
    void readRecipe()
    {
        var record = new DataService("dbApp.db");
        var recRecipe = record.GetRecipe();
        idRecipe(recRecipe);
    }
    private void idRecipe(IEnumerable<Recipe> recipe){
		foreach (var rec in recipe) {
			id.Add(rec.Idrecipe());
            titleLs.Add(rec.recTitle());
		}
	}

    void RecipeInstantiate(string name,string id)
    {
        //Instantiate prefabs and assign locatio
        newObj = Instantiate(rcpItem);
        newObj.transform.SetParent(GameObject.Find("Content").transform); 
        newObj.name = id;
        newObj.AddComponent<Button>().onClick.AddListener(()=>{ btnClick();});
        newObj.transform.GetChild(1).GetComponent<Text>().text = name;
        newObj.transform.GetChild(0).GetComponent<Image>().sprite = Resources.Load<Sprite>(name); 
    }
    public void btnClick()
    {
        var currentEventSystem = EventSystem.current;
        var currentSelectedGameObject = currentEventSystem.currentSelectedGameObject;
        rcpClick = currentSelectedGameObject.name;
        RcpDisplay.setprevscene(thisScene);
        RcpDisplay.setId(rcpClick);
        SceneManager.LoadScene("RecipeSc");
    }

    void btnBack()
    {
        suggstLst.Clear();
        SceneManager.LoadScene("SuggesterSc");
    }

}
