﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class RegionsChat : MonoBehaviour
{
    private Button btnLuzon, btnVis, btnMind, btnBack;
    // Start is called before the first frame update
    void Start()
    {
        GameObject.Find("BtnLuzon").GetComponent<Button>().onClick.AddListener(()=> { btnClick("Luzon"); });
        GameObject.Find("BtnVisayas").GetComponent<Button>().onClick.AddListener(()=> { btnClick("Visayas"); });
        GameObject.Find("BtnMind").GetComponent<Button>().onClick.AddListener(()=> { btnClick("Mindanao"); });
        GameObject.Find("BtnBack").GetComponent<Button>().onClick.AddListener(()=> { btnback(); });
    }
    void Update()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                btnback();
                return;
            }
        }
    }

    void btnClick(string reg)
    {
        RegionLs.setrgnSelc(reg);
        SceneManager.LoadScene("RecipeRegion");
    }
    void btnback()
    {
        SceneManager.LoadScene("Main");
    }
    
}
