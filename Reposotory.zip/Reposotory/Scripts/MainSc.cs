﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class MainSc : MonoBehaviour
{
    private Button btnHelp, btnSgst, btnOrgn, btnExit;
    // Start is called before the first frame update
    void Start()
    {
        btnSgst = GameObject.Find("BtnSug").GetComponent<Button>();
        btnSgst.onClick.AddListener(()=> { btnClick("SuggesterSc"); });

        btnOrgn = GameObject.Find("BtnOrigin").GetComponent<Button>();
        btnOrgn.onClick.AddListener(()=> { btnClick("RegionSc"); });

        btnHelp = GameObject.Find("BtnHelp").GetComponent<Button>();
        btnHelp.onClick.AddListener(()=> { btnClick("HelpSc"); });

        btnExit = GameObject.Find("BtnExit").GetComponent<Button>();
        btnExit.onClick.AddListener(()=> { btnexit(); }); 
    }

    void Update()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                Application.Quit();
                return;
            }
        }
    }

    void btnClick(string scene)
    {
        SceneManager.LoadScene(scene);
    }
    void btnexit()
    {
        Application.Quit();
    }
    
}
