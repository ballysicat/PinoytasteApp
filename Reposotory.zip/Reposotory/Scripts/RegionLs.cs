﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Text.RegularExpressions;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class RegionLs : MonoBehaviour 
{
    public GameObject rcpItem;
    GameObject newObj;
    private static string thisScene = "RecipeRegion";
    private static string rcpClick;
    private static string rgnSelc;
    private List<string> id = new List<string>();
    private List<string> titleLs = new List<string>();

    void Start()
    {
        readRecipe();
        GameObject.Find("TxtPromt").GetComponent<Text>().text = "Mabuhay! Enjoy the delicious recipe from " + rgnSelc;
        
        for(int i=0; i < id.Count; i++)
            RecipeInstantiate(titleLs[i], id[i]);
        
        GameObject.Find("Scroll").GetComponent<ScrollRect>().verticalNormalizedPosition = 1;
        GameObject.Find("BtnBack").GetComponent<Button>().onClick.AddListener(()=>{btnBack();});
    }
    void Update()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                btnBack();
                return;
            }
        }
    }
    void readRecipe()
    {
        var record = new DataService("dbApp.db");
        var recRegion = record.GetRecipe();
        SelRegion(recRegion);
    }
    private void SelRegion(IEnumerable<Recipe> recipe)
    {
		foreach(var rec in recipe)
        {
            if(rec.GetRegion() == rgnSelc)
            {
                id.Add(rec.GetId().ToString());
                titleLs.Add(rec.GetTitle());
            }
        }
	}

    void RecipeInstantiate(string name,string id)
    {
        //Instantiate prefabs 
        newObj = Instantiate(rcpItem);
        newObj.transform.SetParent(GameObject.Find("Content").transform); 
        newObj.name = id;
        newObj.AddComponent<Button>().onClick.AddListener(btnClick);
        newObj.transform.GetChild(0).GetComponent<Image>().sprite = Resources.Load<Sprite>(name);
        newObj.transform.GetChild(1).GetComponent<Text>().text = name;
    }
    public void btnClick()
    {
        var currentEventSystem = EventSystem.current;
        var currentSelectedGameObject = currentEventSystem.currentSelectedGameObject;
        rcpClick = currentSelectedGameObject.name;
        RcpDisplay.setprevscene(thisScene);
        RcpDisplay.setId(rcpClick);
        SceneManager.LoadScene("RecipeSc");
    }
    void btnBack()
    {
        SceneManager.LoadScene("RegionSc");
    }
    public static void setrgnSelc(string regn)
    {
        rgnSelc = regn;
    }
    
}
