﻿using SQLite4Unity3d;

public class AllIngredients 
{
    public string meat { get; set; }
	public string seaFoods { get; set; }
	public string vegetable { get; set; }
	public string fruits { get; set; }
    public string condiments { get; set; }
    public string others { get; set; }

    public string Meat(){ return meat;}
    public string SeaFoods(){ return seaFoods; }
    public string Vegetable(){  return vegetable; }
    public string Fruits(){ return fruits; }
    public string Condiments(){ return condiments; }
    public string Others(){  return others; }

}
