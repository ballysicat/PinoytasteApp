﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Text.RegularExpressions;
using System;
using UnityEngine.SceneManagement;


public class RcpDisplay : MonoBehaviour
{
    //protected const string  dbName = "URI=file:dbApp.db";
    private static string id;
    private static string prevscene;
    private string idsource;
    private string title;
    private string region;
    private string imagelink;
    private string description;
    private string ingredients;
    private string procedures;
    private string[] ingArray, proArray;
    private bool flagAudio;
    private string[] flag = new string[2];
    private int padding;
    public GameObject IngPrefb;
    public GameObject ProPrefb;
    public GameObject txtIngLabel;
    GameObject crtObj, childObj;
    Text   textProce;
    //Audio setUp  
    [Header("Audio Stuff")]
    private AudioSource audioSource;
    private AudioClip audioClip;

    // Start is called before the first frame update
    void Start()
    {
        readRecipe();
        audioSource = gameObject.AddComponent<AudioSource>();
        GameObject.Find("TitleDish").GetComponent<Text>().text = "TITLE: " +title;
        GameObject.Find("Link").GetComponent<Text>().text = imagelink;
        GameObject.Find("RegionDish").GetComponent<Text>().text = "From " + region + " Region";
        GameObject.Find("ImgDish").GetComponent<Image>().sprite = Resources.Load<Sprite>(title);

        for(int i=0; i<ingArray.Length; i++)
        {
            if(ingArray[i].Contains(">"))
            { 
                crtObj = Instantiate(txtIngLabel);
                crtObj.transform.SetParent(GameObject.Find("IngCont").transform);
                crtObj.GetComponent<Text>().text = Regex.Replace(ingArray[i], @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline);
            }
            else
            {
                crtObj = Instantiate(IngPrefb);
                crtObj.transform.SetParent(GameObject.Find("IngCont").transform);
                childObj = crtObj.transform.GetChild(1).gameObject;
                childObj.GetComponent<Text>().text = Regex.Replace(ingArray[i], @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline);
            }
        }

        GameObject.Find("TxtDesc").GetComponent<Text>().text = description;
    
        for(int i=0; i<proArray.Length; i++)
        {
            textProce = GameObject.Find("TxtProc").GetComponent<Text>();
            textProce.text += "\n"+(i + 1) +"). "+ Regex.Replace(proArray[i], @"^\s*$[\r\n]*", string.Empty, RegexOptions.Multiline) + "\n";  
            crtObj = Instantiate(ProPrefb);
            crtObj.name = (i+1).ToString();
            crtObj.transform.SetParent(GameObject.Find("ProcCont").transform);
            crtObj.GetComponent<Button>().onClick.AddListener(() => {btnClick(); });
            padding+= 20;
        }
        GameObject.Find("ProcCont").GetComponent<VerticalLayoutGroup>().padding.bottom = padding;;
        GameObject.Find("Scrll").GetComponent<ScrollRect>().verticalNormalizedPosition = 1;
        GameObject.Find("BtnBack").GetComponent<Button>().onClick.AddListener(()=>{btnBack();});
    }
    void Update()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                btnBack();
                return;
            }
        }
    }

    void btnClick()
    {
        var currentEventSystem = EventSystem.current;
        var currentSelectedGameObject = currentEventSystem.currentSelectedGameObject;
        string audioFile = region + "/" + title + "/" + currentSelectedGameObject.name ;
        if(flag[0] == null)
        {
            flag[0] = currentSelectedGameObject.name;
            btnStopPlay(flag[0], "stpBtn");
            PlayAudioFile(audioFile);
        }
        else if(flag[0] != null && flag[0] != currentSelectedGameObject.name)
        {
            flagAudio = false;
            flag[1] = flag[0];
            flag[0] = currentSelectedGameObject.name;
            btnStopPlay(flag[0],"stpBtn");
            btnStopPlay(flag[1], "playBtn");
            PlayAudioFile(audioFile);
        }
        else
        {
            if(flagAudio != true)
            {
                flagAudio = true;
                audioSource.Stop();
                btnStopPlay(flag[0], "playBtn");
            }
            else
            {
                flagAudio = false;
                audioSource.Play();
                btnStopPlay(flag[0], "stpBtn");
            }
        }
    }



    void btnStopPlay(string btnNum, string btnBG)
    {
        GameObject.Find(btnNum).GetComponent<Button>().image.sprite = Resources.Load<Sprite>(btnBG);
    }

    private void PlayAudioFile(string fldr)
    {
        audioSource.clip = (AudioClip)Resources.Load(fldr);
        audioSource.Play();
        audioSource.loop = false;
    }

    void readRecipe()
    {
        var record = new DataService("dbApp.db");
        var recRecipe = record.GetRecipe();
        idRecipe(recRecipe);
    }
     private void idRecipe(IEnumerable<Recipe> recipe){
		foreach (var rec in recipe) {
			if(rec.Idrecipe()  == id)
            {
                title       = rec.GetTitle();
                region      = rec.GetRegion();
                description = rec.GetDesc();
                ingredients = rec.GetIng();
                procedures  = rec.GetProc();
                imagelink   = rec.GetLink();
                break;
            }
		}
        Regex MyRegex = new Regex("[^a-z]", RegexOptions.IgnoreCase);
        ingArray    = ingredients.Split(char.Parse(","));
        proArray    = procedures.Split(char.Parse("*"));
	}
    

    void btnBack()
    {
        id = "";
        SceneManager.LoadScene(prevscene);
    }

    public static void setprevscene(string sc)
    {
        prevscene = sc;
    }
    public static void setId(string rcpid)
    {
        id = rcpid;
    }
    
}
