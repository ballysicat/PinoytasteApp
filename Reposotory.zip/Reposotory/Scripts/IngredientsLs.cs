﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Text.RegularExpressions;
using UnityEngine.SceneManagement;

public class IngredientsLs : MonoBehaviour
{
    public GameObject togglePrfb;
    private Text textValue, Childtxt;
    private Button btnAddCom;
    private List<string> meatLst = new List<string>();
    private List<string> seafdLst = new List<string>();
    private List<string> fruitLst = new List<string>();
    private List<string> vegeLst = new List<string>();
    private List<string> condmLst = new List<string>();
    private List<string> othersLst = new List<string>();
    private List<string> idRecipe = new List<string>();
    private List<string> ingRecipe = new List<string>();
    private List<int> ingfound = new List<int>();
    public static List<string> suggstlst = new List<string>();
   
    List<GameObject> tggleLst = new List<GameObject>();
    List<string> selctIngLst = new List<string>();
    List<string> toggleType = new List<string>();
    int middIndex, i;
    bool showmeat = false;
    bool showseaFd = false;
    bool showvege = false;
    bool showfruit = false;
    bool showcondm = false;
    bool showother = false;
    bool typeTogg = false;
    GameObject meatcol1, meatcol2;
    GameObject seaFcol1, seaFcol2;
    GameObject vegecol1, vegecol2;
    GameObject fruitcol1, fruitcol2;
    GameObject condmcol1, condmcol2;
    GameObject othercol1, othercol2;
    GameObject boxinfo;
    List<KeyValuePair<string, int>> idFound = new List<KeyValuePair<string, int>>();

    // Start is called before the first frame update
    void Start()
    {
        readIngredients();
        removeEmptyString(meatLst);
        removeEmptyString(seafdLst);
        removeEmptyString(fruitLst);
        removeEmptyString(vegeLst);
        removeEmptyString(condmLst);
        removeEmptyString(othersLst);

        middIndex = meatLst.Count / 2;
        i = meatLst.Count;
        for(int x=0; x < i; x++)
        {
            if(x < middIndex)
                createToggle("MeatCol1", meatLst[x], "Meat");
            else
                createToggle("MeatCol2", meatLst[x], "Meat");   
        }

        middIndex = seafdLst.Count / 2;
        i = seafdLst.Count;
        for(int x=0; x < i; x++)
        {
            if(x < middIndex)
                createToggle("SeaFdCol1", seafdLst[x], "SeaFd");
            else
                createToggle("SeaFdCol2", seafdLst[x], "SeaFd");    
        }

        middIndex = vegeLst.Count/2;
        i = vegeLst.Count;
        for(int x=0; x < i; x++)
        {
            if(x < middIndex)
                createToggle("VegeCol1", vegeLst[x], "Vege");
            else
                createToggle("VegeCol2", vegeLst[x], "Vege");     
        }  

        middIndex = fruitLst.Count/2;
        i = fruitLst.Count;
        for(int x=0; x < i; x++)
        {
            if(x < middIndex)
                createToggle("FruitCol1", fruitLst[x], "Fruit");
            else
                createToggle("FruitCol2", fruitLst[x], "Fruit");    
        }  

        middIndex = condmLst.Count/2;
        i = condmLst.Count;
        for(int x=0; x < i; x++)
        {
            if(x < middIndex)
                createToggle("CndmCol1", condmLst[x], "Cdmnts");
            else
                createToggle("CndmCol2", condmLst[x], "Cdmnts");    
        }     

        middIndex = othersLst.Count/2;
        i = othersLst.Count;
        for(int x=0; x < i; x++)
        {
            if(x < middIndex)
                createToggle("OthersCol1", othersLst[x], "Others");
            else
                createToggle("OthersCol2", othersLst[x], "Others");   
        }
         
        //Position the canvas to top
        GameObject.Find("Scroll").GetComponent<ScrollRect>().verticalNormalizedPosition = 1;
        GameObject.Find("BtnSelc").GetComponent<Button>().onClick.AddListener(()=> {getToggleCheck(); });
        //set meat active to true/fasle
        GameObject.Find("BtnMeat").AddComponent<Button>().onClick.AddListener(()=> {showMeat(); });
        meatcol2 = GameObject.Find("LstMeat");
        meatcol1 = GameObject.Find("MeatCol1"); 
        // //set seaFd active to true/fasle
        GameObject.Find("BtnSeaFd").AddComponent<Button>().onClick.AddListener(()=> {showSeaFd(); });
        seaFcol1 = GameObject.Find("SeaFdCol1");
        seaFcol2 = GameObject.Find("LstSeaFd");
        // //set Vege active to true/fasle
        GameObject.Find("BtnVege").AddComponent<Button>().onClick.AddListener(()=> {showVege(); });
        vegecol1 = GameObject.Find("VegeCol1");
        vegecol2 = GameObject.Find("LstVege");
        // //set fruit active to true/fasle
        GameObject.Find("BtnFruit").AddComponent<Button>().onClick.AddListener(()=> {showFruit(); });
        fruitcol1 = GameObject.Find("FruitCol1");
        fruitcol2 = GameObject.Find("LstFriut");
        // //set Condements active to true/fasle
        GameObject.Find("BtnCondm").AddComponent<Button>().onClick.AddListener(()=> {showCondm(); });
        condmcol1 = GameObject.Find("CndmCol1");
        condmcol2 = GameObject.Find("LstCondmnt");
        // //set others Ingrdnts active to true/fasle
        GameObject.Find("BtnOther").AddComponent<Button>().onClick.AddListener(()=> {showOther(); });
        othercol1 = GameObject.Find("OthersCol1");
        othercol2 = GameObject.Find("LstOthers");

        GameObject.Find("BtnBack").GetComponent<Button>().onClick.AddListener(()=> { btnback(); });
        GameObject.Find("BtnSelc").GetComponent<Button>().onClick.AddListener(()=> { getToggleCheck(); });
                  
        boxinfo = GameObject.Find("BgInfo");
        boxinfo.SetActive(false);
        boxinfo.transform.GetChild(1).GetComponent<Button>().onClick.AddListener(()=>{ showInfo();});
        
        toggleHidden(); 

        
    }
    void Update()
    {
        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                btnback();
                return;
            }
        }
    }
    void showMeat()
    {
        if(showmeat == true)
        {
            meatcol1.SetActive(false);
            meatcol2.SetActive(false);
            showmeat = false;
        }
        else
        {
            meatcol1.SetActive(true);
            meatcol2.SetActive(true);
            showmeat = true;
        } 
        GameObject.Find("Scroll").GetComponent<ScrollRect>().verticalNormalizedPosition = 1;
    }
    void showSeaFd()
    {
        if(showseaFd == true)
        {
            seaFcol1.SetActive(false);
            seaFcol2.SetActive(false);
            showseaFd = false;
        }
        else
        {
            seaFcol1.SetActive(true);
            seaFcol2.SetActive(true);
            showseaFd = true;
        }
        GameObject.Find("Scroll").GetComponent<ScrollRect>().verticalNormalizedPosition = 0.75f;
    }
    void showVege()
    {
        if(showvege == true)
        {
            vegecol1.SetActive(false);
            vegecol2.SetActive(false);
            showvege = false;
        }
        else
        {
            vegecol1.SetActive(true);
            vegecol2.SetActive(true);
            showvege = true;
        }
        GameObject.Find("Scroll").GetComponent<ScrollRect>().verticalNormalizedPosition = 0.65f;
    }
    void showFruit()
    {
        if(showfruit == true)
        {
            fruitcol1.SetActive(false);
            fruitcol2.SetActive(false);
            showfruit = false;
        }
        else
        {
            fruitcol1.SetActive(true);
            fruitcol2.SetActive(true);
            showfruit = true;
        }
        GameObject.Find("Scroll").GetComponent<ScrollRect>().verticalNormalizedPosition = 0.55f;
    }
    void showCondm()
    {
        if(showcondm== true)
        {
            condmcol1.SetActive(false);
            condmcol2.SetActive(false);
            showcondm = false;
        }
        else
        {
            condmcol1.SetActive(true);
            condmcol2.SetActive(true);
            showcondm = true;
        }
        GameObject.Find("Scroll").GetComponent<ScrollRect>().verticalNormalizedPosition = 0.55f;
    }
    void showOther()
    {
        if(showother== true)
        {
            othercol1.SetActive(false);
            othercol2.SetActive(false);
            showother = false;
        }
        else
        {
            othercol1.SetActive(true);
            othercol2.SetActive(true);
            showother = true;
        }
    }

    void removeEmptyString(List<string> mylist)
    {
        mylist.Sort();
        for(int x=mylist.Count -1; x> -1; x--)
        {
            if(mylist[x] == string.Empty) 
            {
                mylist.RemoveAt(x);
            }
        }
    }

    void toggleHidden()
    {
        meatcol1.SetActive(false);
        meatcol2.SetActive(false);
        seaFcol1.SetActive(false);
        seaFcol2.SetActive(false);
        vegecol1.SetActive(false);
        vegecol2.SetActive(false);
        fruitcol1.SetActive(false);
        fruitcol2.SetActive(false);
        condmcol1.SetActive(false);
        condmcol2.SetActive(false);
        othercol1.SetActive(false);
        othercol2.SetActive(false);
    }

    void createToggle(string parentObj, string taggleValue, string tg)
    {
        GameObject Obj = Instantiate(togglePrfb);
        Obj.name = strtrim(taggleValue.ToUpper());
        Obj.tag = tg;
        tggleLst.Add(Obj);
        Obj.transform.SetParent(GameObject.Find(parentObj).transform);
        Obj.transform.GetChild(1).GetComponent<Text>().text = taggleValue.ToUpper();
    }

    void getToggleCheck()
    {
        var crt = tggleLst.Count;
        for(int i=0; i < crt; i++)
        {
            if(tggleLst[i].GetComponent<Toggle>().isOn)
            {
                selctIngLst.Add(tggleLst[i].GetComponent<Toggle>().name);
                toggleType.Add(tggleLst[i].GetComponent<Toggle>().tag);
            }          
        }
        if(toggleType.Contains("Meat"))
            typeTogg = true;
        if(toggleType.Contains("Fruit"))
            typeTogg = true;
        if(toggleType.Contains("Vege"))
            typeTogg = true;
        if(toggleType.Contains("SeaFd"))
            typeTogg = true;
        if(toggleType.Contains("Others"))
            typeTogg = true;
        if(typeTogg == false)
        {   
            var tmp = 0;
            foreach (var item in toggleType)
            {
                if(tmp > 2)
                {
                    typeTogg = true;
                    break;
                }  
                if(item == "Cdmnts")
                    tmp ++;
            }          
        }
        scanSelIngrdnts();
        setSuggstList();
    }
    string strtrim(string str)
    {
        if(str.IndexOf("*") > -1)
            return str.Remove(str.IndexOf("*"));
        else
            return str;
    }

    void scanSelIngrdnts()
    {
        var crt2 = ingRecipe.Count; 
        for(int i=0; i< crt2; i++)
        {    
            for(int x=0; x < selctIngLst.Count; x++)
            {
                if(ingRecipe[i].Contains(selctIngLst[x]))
                    ingfound[i] += 1;
            }
        }
    }

    void setSuggstList()
    {
        if(typeTogg == true)
        {
            for(int x=0; x< ingfound.Count; x++)
                idFound.Add(new KeyValuePair<string, int>(idRecipe[x], ingfound[x]));
            ingfound.Sort();
            idFound.Sort(Compare1);
            idFound.Sort(Compare2);
            var ctr = idFound.Count -1;
            for(int x=ctr ; x > -1; x--)
            {
                var numID = idFound[x].ToString();
                if(ingfound[x] > 0)
                    suggstlst.Add(numID.Substring (1, numID.IndexOf(",")-1));
            }
            ResultSuggest.setsuggstLst(suggstlst);
            SceneManager.LoadScene("SuggstLstSc");
        }
        else
        {
            boxinfo.SetActive(true);
        }
            
    }

    void btnback()
    {
        SceneManager.LoadScene("Main");
    }
    static int Compare1(KeyValuePair<string, int> a, KeyValuePair<string, int> b)
    {
    return a.Key.CompareTo(b.Key);
    }

    static int Compare2(KeyValuePair<string, int> a, KeyValuePair<string, int> b)
    {
    return a.Value.CompareTo(b.Value);
    }

    void readIngredients()
    {
        var record = new DataService("dbApp.db");
        var meat = record.GetAllIngr();
        AddIngrChat(meat);

        var recRecipe = record.GetRecipe();
        getIngrAndID(recRecipe);
    }

    private void AddIngrChat(IEnumerable<AllIngredients> ingrdnt)
    {
		foreach (var rec in ingrdnt) 
        {
            if(rec.Meat() != null)
			    meatLst.Add(rec.Meat());
            if(rec.SeaFoods() != null)
			    seafdLst.Add(rec.SeaFoods());
            if(rec.Vegetable() != null)
			    vegeLst.Add(rec.Vegetable());
            if(rec.Fruits() != null )
			    fruitLst.Add(rec.Fruits());
            if(rec.Condiments() != null)
			    condmLst.Add(rec.Condiments());
            if(rec.Others() != null)
			    othersLst.Add(rec.Others());
		}
	}

    private void getIngrAndID(IEnumerable<Recipe> recipe){
		foreach (var rec in recipe) {
			idRecipe.Add(rec.Idrecipe());
            ingRecipe.Add(rec.IngreRecipe().ToUpper());
            ingfound.Add(0);
		}
	}
    
    void showInfo()
    {
        boxinfo.SetActive(false);
    }
}
