﻿using SQLite4Unity3d;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Recipe 
{
    [PrimaryKey, AutoIncrement]
	public int id { get; set; }
	public string title { get; set; }
	public string region { get; set; }
	public string description { get; set; }
    public string ingredients { get; set; }
    public string procedures { get; set; }
    public string imageLink { get; set; }

	private static List<string> listrecipe = new List<string>();

	public override string ToString ()
	{
		return string.Format ("{0}=, {1}=,  {2}=, {3}=, {4}=, {5}=, {6}", id, title, region, description,ingredients,procedures,imageLink );
	}

	public int GetId()
	{
		return id;
	}
	public string GetTitle()
	{
		return title;
	}

	public string GetRegion()
	{
		return region;
	}
	public string GetDesc()
	{
		return description;
	}
	public string GetIng()
	{
		return ingredients;
	}
	public string GetProc()
	{
		return procedures;
	}
	public string GetLink()
	{
		return imageLink;
	}

	public string Idrecipe(){ return id.ToString();}
	public string recTitle(){ return title;}
	public string IngreRecipe(){ return ingredients;}
}
